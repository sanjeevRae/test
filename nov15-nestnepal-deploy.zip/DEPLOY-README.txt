NOV15 - BODHISATTVA EXHIBITION SITE - NEST NEPAL (cPanel) DEPLOY
================================================================

The website plus a working contact form.

HOW THE FORM SENDS
------------------
The form emails each enquiry FROM
website@bodhisattvainternational.com (a mailbox created only for
this website) TO info@bodhisattvainternational.com, logging in
with the website@ password over encrypted SMTP (SSL, port 465).
No third-party service, no activation.

DEPLOY - 5 STEPS
----------------
1. cPanel -> File Manager -> public_html -> Upload this ZIP ->
   right-click -> Extract. Files must sit directly in public_html.

2. cPanel -> Email Accounts -> Create -> create the mailbox:
      Email:  website@bodhisattvainternational.com
      Password: choose one and note it down.
   (This mailbox is only for sending; nobody reads mail in it.)

3. Move the settings file OUT of the web folder (the secure way -
   no browser can ever reach it there):
   In File Manager, drag  contact-config.php  from public_html
   into the account HOME folder (one level above public_html).

4. Open contact-config.php (in its new home) -> Edit, and fill in
   ONE value:
      'smtp_pass' => 'the website@ password from step 2'
   Sender (website@) and receiver (info@) are already set. Save.

5. Open the website and send a test enquiry from the form. It
   should arrive in the info@bodhisattvainternational.com inbox
   within a minute, with Reply-To set to the visitor's email -
   so replying goes straight to the visitor.

IF A TEST DOES NOT ARRIVE
-------------------------
- Check the Spam folder of the info@ mailbox.
- Re-check 'smtp_pass' - it must be the exact password chosen in
  step 2 for website@bodhisattvainternational.com.
- cPanel -> Email Deliverability: the domain should show SPF and
  DKIM as "Valid" (cPanel normally sets these up itself). This
  keeps the messages out of Spam.
- Make sure the site opens with https (padlock); run AutoSSL in
  cPanel if it does not.

SECURITY NOTE
-------------
- The only secret is the website@ password, and it lives only in
  contact-config.php, which step 3 moves outside the public web
  folder. That mailbox holds no mail of its own; if its password
  is ever changed, just update this one file.
- Needs PHP 7.4+ (standard on Nest Nepal). Nothing to build.
